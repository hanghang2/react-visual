import React,{Component} from 'react';

class Component2 extends Component{
    render() {
        return (
            <div>Component2</div>
        )
    }
}

export default Component2;
