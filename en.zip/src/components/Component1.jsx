import React,{Component} from 'react';

class Component1 extends Component{
    render() {
        return (
            <div>Component1</div>
        )
    }
}

export default Component1;
