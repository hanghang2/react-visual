import React, {Component} from 'react';

import Component1 from '../components/Component1'
import Component2 from '../components/Component2'

import GridStack from "gridstack/dist/gridstack.all.js";
import "gridstack/dist/gridstack.css";
import './index.css'

var allComponent = {Component1, Component2}

class Index extends Component {
    constructor(props) {
        super(props)
        //读取缓存数据
        let data = sessionStorage.getItem('data')
        data = data ? JSON.parse(data) : [];
        data = data.map((item) => {
            item.component = allComponent[item.name]
            return item;
        })
        this.state = {
            gridList: data
        }
    }
    
    /**
     * 组建挂载完成
     */
    componentDidMount() {
        this.gridStack = GridStack.init({margin: 10, cellHeight: 5, removeTimeout: 100}, this.gridStackDom)
    }
    
    /**
     * dom更新过滤
     * @param nextProps
     * @param nextState
     * @returns {boolean} 判断是否要更新render,  return true 更新  return false不更新
     */
    shouldComponentUpdate(nextProps, nextState) {
        return true;
    }
    
    render() {
        return (
            <div className='index'>
                <header>
                    <li onClick={this.addComponent.bind(this, 'Component1')}>新增 Component1</li>
                    <li onClick={this.addComponent.bind(this, 'Component2')}>新增 Component2</li>
                    <li onClick={this.save}>保存</li>
                </header>
                <main>
                    <div className='grid-stack' ref={(dom) => {
                        this.gridStackDom = dom
                    }}>
                        {
                            this.state.gridList.map((item, index) => {
                                return (
                                    <div key={item.key}
                                         id={'grid-item' + index}
                                         className='grid-stack-item'
                                         component-key={item.key}
                                         component-name={item.name}
                                         data-gs-width={item.width || "6"}
                                         data-gs-height={item.height || "50"}
                                         data-gs-x={item.x || ""}
                                         data-gs-y={item.y || ""}>
                                        <div className='grid-stack-item-content'>
                                            <span
                                                className='grid-stack-item-del'
                                                onClick={this.delItem.bind(this, index)}>
                                                删除
                                            </span>
                                            <div className='component'>
                                                <item.component/>
                                            </div>
                                        </div>
                                    </div>
                                )
                            })
                        }
                    </div>
                </main>
            </div>
        )
    }
    
    /**
     * 新增模块
     * @param name 组件名称
     */
    addComponent(name) {
        this.setState({
            gridList: [
                ...this.state.gridList,
                {
                    name,
                    component: allComponent[name],
                    key: (new Date()).getTime() //生成key保证能够正确删除dom
                }
            ]
        }, () => {
            //把标签作为gridStack元素
            this.gridStack.makeWidget('#grid-item' + (this.state.gridList.length - 1))
        })
        
    }
    
    /**
     * 删除模块
     * @param index 删除索引
     */
    delItem(index) {
        //param1:：标签，param2：不删除dom （否则react render时候报错找不到删除节点）
        this.gridStack.removeWidget(document.getElementById('grid-item' + index), false);
        this.setState(() => {
            let gridList = [...this.state.gridList];
            gridList.splice(index, 1)
            return {
                gridList
            }
        })
    }
    
    /**
     * 保存页面
     */
    save = () => {
        let data = this.state.gridList.map((item, index) => {
            let itemDom = document.getElementById('grid-item' + index);
            return {
                key: itemDom.getAttribute('component-key'),
                name: itemDom.getAttribute('component-name'),
                width: itemDom.getAttribute('data-gs-width'),
                height: itemDom.getAttribute('data-gs-height'),
                x: itemDom.getAttribute('data-gs-x'),
                y: itemDom.getAttribute('data-gs-y'),
            }
        })
        sessionStorage.setItem('data', JSON.stringify(data))
    }
}

export default Index;
